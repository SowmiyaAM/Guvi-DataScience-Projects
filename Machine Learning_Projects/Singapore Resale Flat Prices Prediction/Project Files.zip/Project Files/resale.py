import pandas as pd
import numpy as np
import pickle
import json
import streamlit as st
from streamlit_option_menu import option_menu

dtypes = {
    'month' : 'str',
    'town' : 'str',
    'flat_type' : 'str',
    'block' : 'str',
    'street_name' : 'str',
    'storey_range' : 'str',
    'floor_area_sqm' : 'float64',
    'flat_model' : 'str',
    'lease_commence_date' : 'int64',
    'resale_price' : 'float64',
    'remaining_lease' : 'str'
}
resale_data = pd.read_csv("/workspaces/dev/Singapore_Resale_Flat_Price/resale_data.csv",dtype=dtypes)

with open("/workspaces/dev/Singapore_Resale_Flat_Price/town_map", "r") as file:
    loaded_town_dict = json.load(file)
town_list = list(loaded_town_dict.keys())
with open("/workspaces/dev/Singapore_Resale_Flat_Price/flat_type_map", "r") as file:
    loaded_flat_type_dict = json.load(file)
flat_type_list = list(loaded_flat_type_dict.keys())
with open("/workspaces/dev/Singapore_Resale_Flat_Price/flat_model_map", "r") as file:
    loaded_flat_model_dict = json.load(file)
flat_model_list = list(loaded_flat_model_dict.keys())

# Load the model from the file
with open('/workspaces/dev/Singapore_Resale_Flat_Price/prediction.pkl', 'rb') as file:
    loaded_rf_model = pickle.load(file)

st.set_page_config(layout="wide")
st.title(":red[SINGAPORE RESALE FLAT PRICE PREDICTION]")

col1, col2 = st.columns(2)
with col1:
    town = st.selectbox("Town",town_list)
    town_enc = loaded_town_dict.get(town)
    flat_type = st.selectbox("Flat Type",flat_type_list)
    flat_type_enc = loaded_flat_type_dict.get(flat_type)
    flat_model = st.selectbox("Flat Model",flat_model_list)
    flat_model_enc = loaded_flat_model_dict.get(flat_model)
with col2:
    storey_range = st.selectbox("Storey Range",resale_data["storey_range"].unique().tolist())
    storey_range_start, storey_range_end = storey_range.split(" TO ")
    storey_range_start_int = int(storey_range_start)
    storey_range_end_int = int(storey_range_end)
    floor_area_sqm = st.text_input("Floor Area (in sqm) (Range : 0 to 400)",value=0)
    floor_area_sqm_int = int(floor_area_sqm)
    remaining_lease_years = st.text_input("Remaining Lease Years (Range : 0 to 99)",value=0)
    remaining_lease_years_int = int(remaining_lease_years)

if st.button("Predict Resale Price",use_container_width = True):
    user_input = np.array([[floor_area_sqm_int,storey_range_start_int,storey_range_end_int,remaining_lease_years_int,town_enc,flat_type_enc,flat_model_enc]])
    pred_user_output = loaded_rf_model.predict(user_input)
    predicted_resale_price = np.exp(pred_user_output[0])
    st.write("Predicted Resale Price",predicted_resale_price)


